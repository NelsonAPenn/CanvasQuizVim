alert("FUCK ME");
var defaultBorder = "0px solid red";
var styledBorder = "10px solid red";
var questionIndex = -1;
var responses = [];
var questions;
function yPosition(elem)
{
  return elem.getBoundingClientRect().top - document.body.getBoundingClientRect().top;
}
function xPosition(elem)
{
  return elem.getBoundingClientRect().left - document.body.getBoundingClientRect().left;
}
function center()
{
  window.scrollTo(0,yPosition(questions[questionIndex].parentElement.parentElement));
}
window.addEventListener("load", (event) => {
  questions = document.getElementsByClassName("answers");
  console.log(questions);
  questionIndex = 0;
  responseIndex = 0;
  for(var i = 0; i < questions.length; i++)
  {
    questions[i].style.border = defaultBorder;
    var inputs = questions[i].getElementsByTagName("input"); 
    responses.push( { collection: inputs, index: 0 } );
    inputs[0].click();
  }
  questions[questionIndex].style.border = styledBorder;
  center();
});
function nextResponse()
{
  responses[questionIndex].index++;
  if(responses[questionIndex].index === responses[questionIndex].collection.length)
    responses[questionIndex].index = 0;
  responses[questionIndex].collection[responses[questionIndex].index].click();
}
function previousResponse()
{
  responses[questionIndex].index--;
  if(responses[questionIndex].index === -1)
    responses[questionIndex].index = responses[questionIndex].collection.length - 1;
  responses[questionIndex].collection[responses[questionIndex].index].click();
}
function nextQuestion()
{
  questions[questionIndex].style.border = defaultBorder;
  questionIndex++;
  if(questionIndex === questions.length)
    questionIndex = 0;
  questions[questionIndex].style.border = styledBorder;
  center();
}
function previousQuestion()
{
  questions[questionIndex].style.border = defaultBorder;
  questionIndex--;
  if(questionIndex === -1)
    questionIndex = questions.length - 1;
  questions[questionIndex].style.border = styledBorder;
  center();
}
function submitQuiz()
{
  document.getElementById("submit_quiz_button").click();
}
function chooseResponse(i)
{
  if(i >= responses[questionIndex].collection.length)
    return;
  responses[questionIndex].index = i;
  responses[questionIndex].collection[i].click();
}

window.onkeydown = function(e)
{
  switch(e.keyCode)
  {
    case 72: // H
      previousResponse();
      break;
    case 74: // J
      nextQuestion();
      break;
    case 75: // K
      previousQuestion();
      break;
    case 76: // L
      nextResponse();
      break;
    case 13: // Enter
      submitQuiz();
      break;
    default:
      var i = e.keyCode - 48;
      if(i < 10)
        chooseResponse(i);
      break;


  }
}
